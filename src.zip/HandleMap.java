import java.util.HashMap;

public class HandleMap extends HashMap<String, EventHandler> {

}
